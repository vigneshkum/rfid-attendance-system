<?php
	$date = str_replace("/","",$_GET["date"]);
	print $date;
?>