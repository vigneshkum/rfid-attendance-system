<?php
exec("getCardSwipe\\getCardID.exe");
?>