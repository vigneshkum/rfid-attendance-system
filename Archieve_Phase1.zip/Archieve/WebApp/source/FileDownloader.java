import processing.core.*; 
import processing.xml.*; 

import processing.serial.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class FileDownloader extends PApplet {



public static final short portIndex = 1; 
Serial myPort;
String date = "02102012";
PrintWriter output;
BufferedReader reader;

public void setup() {  
  //size(200, 200);
  println(Serial.list());
  println(" Connecting to -> " + Serial.list()[portIndex]);
  myPort = new Serial(this, Serial.list()[portIndex], 9600);
  reader = createReader("anchor.txt");
  try {
    date = reader.readLine();
    trim(date);
  }
  catch (IOException e) {
    e.printStackTrace();
  }
  println(date);
  output = createWriter("logs/"+date+".txt");
  myPort.write('F');
  myPort.write(date);
  background(0, 0, 255);
}

public void draw() {
  if (myPort.available()>0) {

    char temp = PApplet.parseChar(myPort.read());
    if (temp == '>') {
      background(0, 255, 0);
      println("End of File");
      output.close();
    }
    else {
      output.print(temp);
      print(temp);
    }
  }
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#F0F0F0", "FileDownloader" });
  }
}
