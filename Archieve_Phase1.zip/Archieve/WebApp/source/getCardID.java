import processing.core.*; 
import processing.xml.*; 

import processing.serial.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class getCardID extends PApplet {



public static final short portIndex = 1; 
Serial myPort;
PrintWriter output;

public void setup() {  
  //size(200, 200);
  println(Serial.list());
  println(" Connecting to -> " + Serial.list()[portIndex]);
  myPort = new Serial(this, Serial.list()[portIndex], 9600);
  output = createWriter("data/cardID.TXT");
  myPort.write("SWIPE");
  background(255, 0, 255);
}

public void draw() {
  if (myPort.available()>0) {

    char temp = PApplet.parseChar(myPort.read());
    if (temp == '>') {
      background(255, 255, 0);
      println("End of File");
      output.close();
    }
    else {
      output.print(temp);
      print(temp);
    }
  }
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#F0F0F0", "getCardID" });
  }
}
